import React, { useState } from "react";
import "./styles.css";

const App = () => {
  const [users, setUser] = useState([]);
  const loadusers = async () => {
    console.log("before");
    const response = await fetch("https://reqres.in/api/users?page=1");
    const json = await response.json();
    setUser(json);
  };
  return (
    <nav class="navbar">
    <div className="App">

      <h1>DAN</h1>
      <button onClick={loadusers}>
        <span>Get Users</span>
        </button>
      <ul>
        {users.map(({ id, login }) => (
          <li key={id}>Name: {login}</li>
        ))}
      </ul>
    </div>
    </nav>
  );
};

export default App;
